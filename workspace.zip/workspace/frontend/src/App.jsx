import { Navigate, Route, Routes, Link, NavLink, useNavigate } from 'react-router-dom';
import { useEffect, useState } from 'react';
import { api, getToken, setToken, money, day, dt } from './api';

const SOCIAL = [
  { id: 'linkedin', label: 'LinkedIn' },
  { id: 'instagram', label: 'Instagram' },
  { id: 'facebook', label: 'Facebook' },
  { id: 'youtube', label: 'YouTube' },
  { id: 'x', label: 'X / Twitter' },
  { id: 'whatsapp', label: 'WhatsApp' }
];

function Logo() {
  return (
    <Link to="/" className="brand">
      <div className="brand-mark">AC</div>
      <div>
        <small>OAB/PA 00.000</small>
        <strong>Andrade Cardoso</strong>
      </div>
    </Link>
  );
}

function PublicNav() {
  return (
    <header className="nav">
      <div className="container nav-inner">
        <Logo />
        <nav className="nav-links">
          <a href="/#areas">Áreas</a>
          <a href="/#banca">Banca</a>
          <a href="/#planos">Planos</a>
          <Link to="/jurisprudencia">Jurisprudência</Link>
          <Link to="/contato">Contato</Link>
          <Link to="/admin" className="btn ghost sm">Painel</Link>
          <Link to="/contato" className="btn sm">Consulta</Link>
        </nav>
      </div>
    </header>
  );
}

function Footer({ social = {} }) {
  return (
    <footer className="footer">
      <div className="container grid-3">
        <div>
          <h4>Andrade Cardoso Advogados</h4>
          <p>Rua 15 de Novembro 2442 - São Benedito</p>
          <p style={{ marginTop: 10 }}>andrade.cardosoadv@gmail.com<br />(91) 99189-0658</p>
        </div>
        <div>
          <h4>Escritório</h4>
          <p><Link to="/jurisprudencia">Radar de jurisprudência</Link></p>
          <p><Link to="/contato">Agendar consulta</Link></p>
          <p><Link to="/admin">Painel do sócio</Link></p>
        </div>
        <div>
          <h4>Redes</h4>
          <div className="socials">
            {SOCIAL.map((s) => (
              <a key={s.id} href={social[s.id] || '#'} target="_blank" rel="noreferrer">
                {s.label}
              </a>
            ))}
          </div>
        </div>
      </div>
      <div className="container footer-bottom">
        <span>© {new Date().getFullYear()} Loops - Agência Digital. Todos os direitos reservados.</span>
        <span>OAB/PA 00.000 · Confidencialidade absoluta.</span>
      </div>
    </footer>
  );
}

function Home() {
  const [data, setData] = useState(null);
  useEffect(() => {
    api('/api/public/firm').then(setData).catch(() => {});
  }, []);
  const plans = data?.plans || [];
  const posts = data?.posts || [];
  const social = data?.social || {};

  return (
    <>
      <PublicNav />
      <section className="hero">
        <div className="container">
          <p className="kicker">Escritório: Cametá - PA</p>
          <h1>Estratégia jurídica. Resultado de sócio.</h1>
          <p className="lead">
            Assessoria contínua para empresas, family offices e conselhos. Contencioso de alta complexidade,
            tributário, trabalhista e sucessões — com presença de sócio em cada matéria crítica.
          </p>
          <div className="hero-actions">
            <Link className="btn" to="/contato">Agendar reunião com sócio</Link>
            <a className="btn ghost" href="#planos">Ver planos de retainer</a>
          </div>
          <div className="stats">
            <div className="stat"><b>10 anos</b><span>de atuação conjunta</span></div>
            <div className="stat"><b>2,1 mi</b><span>em causas sob gestão</span></div>
            <div className="stat"><b>94%</b><span>de retenção de retainer</span></div>
            <div className="stat"><b>4h</b><span>SLA de primeira resposta</span></div>
          </div>
        </div>
      </section>

      <section id="areas">
        <div className="container">
          <div className="section-head">
            <p className="kicker" style={{ color: 'var(--gold)' }}>Prática</p>
            <h2>Áreas em que a banca decide o jogo</h2>
          </div>
          <div className="grid-3">
            {[
              ['01', 'Empresarial e M&A', 'Contratos, joint ventures, due diligence e governança de conselho. Operações conduzidas com sócio na mesa.'],
              ['02', 'Tributário estratégico', 'PIS/COFINS, ágio, transação e CARF. Recuperação de créditos com tese e compliance.'],
              ['03', 'Trabalhista de alto risco', 'Pejotização, C-level, dissídios e TST. Proteção de conselhos e políticas de remuneração.'],
              ['04', 'Família e sucessões', 'Holdings, inventários e acordos que preservam patrimônio e relações.'],
              ['05', 'Contencioso cível', 'Distribuição, infraestrutura e perdas e danos com prova econômica.'],
              ['06', 'LGPD e regulatório', 'Programas de privacidade, ANPD e crise de vazamento com mesa 24/7.']
            ].map(([n, t, d]) => (
              <article className="card" key={n}>
                <div className="area-num">{n}</div>
                <h3>{t}</h3>
                <p className="muted">{d}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section id="banca" className="band">
        <div className="container">
          <div className="section-head">
            <p className="kicker">Sócios</p>
            <h2>Quem assina o parecer também vai à audiência.</h2>
          </div>
          <div className="grid-2">
            <article className="card team-card">
              <div className="avatar">MAC</div>
              <h3>Maurilo Andrade Cardoso</h3>
              <p className="gold">Delegado OAB/PA 00.000 - Cametá</p>
              <p className="muted" style={{ marginTop: 10 }}>
                Ex-conselheiro de companhias abertas. Atua em TST, STJ e crises de reputação.
              </p>
            </article>
            <article className="card team-card">
              <div className="avatar">LC</div>
              <h3>Lorenzo Cardoso</h3>
              <p className="gold">Engenheiro de Software / Ciência de dados</p>
              <p className="muted" style={{ marginTop: 10 }}>
                Especialista em soluções de Automação, Inteligência Artificial e Desenvolvimento.
              </p>
            </article>
          </div>
        </div>
      </section>

      <section id="planos">
        <div className="container">
          <div className="section-head">
            <p className="kicker" style={{ color: 'var(--gold)' }}>Receita recorrente</p>
            <h2>Planos de assessoria contínua</h2>
          </div>
          <div className="grid-3">
            {plans.map((p, i) => (
              <article className={`card ${i === 1 ? 'featured' : ''}`} key={p.id}>
                <p className="muted">{p.name}</p>
                <div className="price">{money(p.price)} <small>/mês</small></div>
                <ul>
                  {(p.features || []).map((f) => <li key={f}>{f}</li>)}
                </ul>
                <Link className="btn full" to="/contato">Solicitar proposta</Link>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="band" style={{ paddingTop: 64, paddingBottom: 64 }}>
        <div className="container grid-2">
          <div>
            <p className="kicker">Inteligência</p>
            <h2 className="serif" style={{ fontSize: 40, fontWeight: 500 }}>Radar em tempo real com STF, STJ, TST, TJSP, TRF-3 e CARF.</h2>
            <p className="muted" style={{ margin: '16px 0 22px', color: '#cfc8b8' }}>
              A banca monitora teses, pautas e acórdãos. Clientes de retainer recebem alertas no painel e por e-mail.
            </p>
            <Link className="btn" to="/jurisprudencia">Abrir jurisprudência ao vivo</Link>
          </div>
          <div>
            {(posts || []).map((p) => (
              <article className="news-item" key={p.id}>
                <time>{p.publishedAt}</time>
                <div>
                  <strong>{p.title}</strong>
                  <p className="muted">{p.excerpt}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>
      <Footer social={social} />
    </>
  );
}

function Jurisprudencia() {
  const [q, setQ] = useState('PIS COFINS insumos');
  const [court, setCourt] = useState('');
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(false);

  async function load(query = q, c = court) {
    setLoading(true);
    try {
      const res = await api(`/api/public/jurisprudence?q=${encodeURIComponent(query)}&court=${encodeURIComponent(c)}`);
      setData(res);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { load(); }, []);

  return (
    <>
      <PublicNav />
      <section>
        <div className="container">
          <p className="kicker" style={{ color: 'var(--gold)' }}>Integração ao vivo</p>
          <h2 className="serif" style={{ fontSize: 48, fontWeight: 500, marginBottom: 12 }}>Jurisprudência dos tribunais superiores</h2>
          <p className="muted" style={{ maxWidth: 70, marginBottom: 24 }}>
            Busca unificada em STF, STJ, TST, TJSP, TRF-3 e CARF, com link oficial para o inteiro teor.
          </p>
          <form className="search-bar" onSubmit={(e) => { e.preventDefault(); load(); }}>
            <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Tese, número ou palavra-chave" />
            <select value={court} onChange={(e) => setCourt(e.target.value)}>
              <option value="">Todos os tribunais</option>
              {(data?.courts || []).map((c) => <option key={c.id} value={c.id}>{c.id} — {c.name}</option>)}
            </select>
            <button className="btn" type="submit">{loading ? 'Buscando…' : 'Buscar'}</button>
          </form>
          <div className="grid-2">
            <div>
              {(data?.items || []).map((item) => (
                <article className="card" key={item.id} style={{ marginBottom: 14 }}>
                  <p className="gold">{item.court} · {item.class} {item.number}</p>
                  <h3 style={{ fontSize: 22 }}>{item.title}</h3>
                  <p className="muted">{item.ementa}</p>
                  <div className="chips">
                    {item.tags.map((t) => <span className="chip" key={t}>{t}</span>)}
                  </div>
                  <p style={{ marginTop: 12 }}>
                    <a className="btn sm ghost" style={{ color: 'var(--ink)', borderColor: 'var(--gold)' }} href={item.sourceUrl} target="_blank" rel="noreferrer">Abrir no {item.court}</a>
                  </p>
                </article>
              ))}
            </div>
            <aside>
              <div className="card">
                <h3>Fontes oficiais</h3>
                {(data?.courts || []).map((c) => (
                  <p key={c.id} style={{ margin: '8px 0' }}>
                    <a href={c.searchUrl} target="_blank" rel="noreferrer">{c.name}</a>
                  </p>
                ))}
              </div>
              <div className="card" style={{ marginTop: 14 }}>
                <h3>Notícias dos tribunais</h3>
                {(data?.news || []).map((n) => (
                  <article className="news-item" key={n.id}>
                    <time>{n.source}</time>
                    <div>
                      <a href={n.url} target="_blank" rel="noreferrer"><strong>{n.title}</strong></a>
                    </div>
                  </article>
                ))}
              </div>
            </aside>
          </div>
        </div>
      </section>
      <Footer />
    </>
  );
}

function Contato() {
  const [form, setForm] = useState({ name: '', email: '', phone: '', company: '', interest: 'Empresarial', message: '', channel: 'site' });
  const [ok, setOk] = useState('');
  const [err, setErr] = useState('');

  function set(k, v) { setForm((f) => ({ ...f, [k]: v })); }

  async function submit(e) {
    e.preventDefault();
    setErr(''); setOk('');
    try {
      const res = await api('/api/public/contact', { method: 'POST', body: form });
      setOk(res.autoReply || 'Mensagem enviada.');
    } catch (ex) {
      setErr(ex.message);
    }
  }

  return (
    <>
      <PublicNav />
      <section>
        <div className="container grid-2">
          <div>
            <p className="kicker" style={{ color: 'var(--gold)' }}>Consulta inicial</p>
            <h2 className="serif" style={{ fontSize: 48, fontWeight: 500 }}>Fale com um sócio.</h2>
            <p className="muted" style={{ margin: '14px 0 22px' }}>
              Resposta automática imediata por e-mail e WhatsApp. Um advogado retorna em até 4 horas úteis.
            </p>
            <p>andrade.cardosoadv@gmail.com<br />(91) 99189-0658</p>
            <p style={{ marginTop: 16 }}>
              <a className="btn" href="https://wa.me/5591991890658" target="_blank" rel="noreferrer">Abrir WhatsApp</a>
            </p>
          </div>
          <form className="card" onSubmit={submit}>
            <div className="row">
              <div className="field"><label>Nome</label><input required value={form.name} onChange={(e) => set('name', e.target.value)} /></div>
              <div className="field"><label>Empresa</label><input value={form.company} onChange={(e) => set('company', e.target.value)} /></div>
            </div>
            <div className="row">
              <div className="field"><label>E-mail</label><input type="email" required value={form.email} onChange={(e) => set('email', e.target.value)} /></div>
              <div className="field"><label>Telefone / WhatsApp</label><input value={form.phone} onChange={(e) => set('phone', e.target.value)} /></div>
            </div>
            <div className="row">
              <div className="field">
                <label>Área</label>
                <select value={form.interest} onChange={(e) => set('interest', e.target.value)}>
                  {['Empresarial', 'Tributário', 'Trabalhista', 'Família e Sucessões', 'LGPD', 'Cível'].map((x) => <option key={x}>{x}</option>)}
                </select>
              </div>
              <div className="field">
                <label>Canal preferido</label>
                <select value={form.channel} onChange={(e) => set('channel', e.target.value)}>
                  <option value="site">E-mail</option>
                  <option value="whatsapp">WhatsApp</option>
                </select>
              </div>
            </div>
            <div className="field"><label>Como podemos ajudar?</label><textarea rows="5" required value={form.message} onChange={(e) => set('message', e.target.value)} /></div>
            <button className="btn full" type="submit">Enviar e disparar automação</button>
            {ok && <div className="alert">{ok}</div>}
            {err && <div className="alert" style={{ color: 'var(--danger)' }}>{err}</div>}
          </form>
        </div>
      </section>
      <Footer />
    </>
  );
}

function RequireAuth({ children }) {
  if (!getToken()) return <Navigate to="/admin/login" replace />;
  return children;
}

function Login() {
  const nav = useNavigate();
  const [email, setEmail] = useState('zoe.m@example.net');
  const [password, setPassword] = useState('admin123');
  const [err, setErr] = useState('');

  async function submit(e) {
    e.preventDefault();
    try {
      const res = await api('/api/auth/login', { method: 'POST', body: { email, password } });
      setToken(res.token);
      nav('/admin');
    } catch (ex) {
      setErr(ex.message);
    }
  }

  return (
    <div className="login-wrap">
      <form className="login-card" onSubmit={submit}>
        <p className="kicker">Painel do sócio</p>
        <h1>Andrade Cardoso</h1>
        <p className="muted" style={{ marginBottom: 18 }}>Acesso restrito à banca.</p>
        <div className="field"><label>E-mail</label><input value={email} onChange={(e) => setEmail(e.target.value)} /></div>
        <div className="field"><label>Senha</label><input type="password" value={password} onChange={(e) => setPassword(e.target.value)} /></div>
        <button className="btn full" type="submit">Entrar</button>
        {err && <div className="alert">{err}</div>}
        <p className="muted" style={{ marginTop: 12, fontSize: 13 }}>zoe.m@example.net · admin123</p>
      </form>
    </div>
  );
}

function Shell({ children }) {
  const nav = useNavigate();
  const links = [
    ['/admin', 'Visão geral'],
    ['/admin/leads', 'Captação / CRM'],
    ['/admin/clientes', 'Clientes e retainers'],
    ['/admin/processos', 'Processos'],
    ['/admin/agenda', 'Agenda'],
    ['/admin/financeiro', 'Financeiro'],
    ['/admin/canais', 'E-mail e WhatsApp'],
    ['/admin/automacoes', 'Automações'],
    ['/admin/jurisprudencia', 'Jurisprudência'],
    ['/admin/config', 'Configurações']
  ];
  return (
    <div className="admin">
      <aside className="side">
        <Logo />
        <nav>
          {links.map(([to, label]) => (
            <NavLink key={to} to={to} end={to === '/admin'} className={({ isActive }) => isActive ? 'active' : ''}>{label}</NavLink>
          ))}
        </nav>
        <button className="btn ghost sm" style={{ marginTop: 24 }} onClick={() => { setToken(null); nav('/'); }}>Sair</button>
      </aside>
      <main className="main">{children}</main>
    </div>
  );
}

function Dashboard() {
  const [d, setD] = useState(null);
  useEffect(() => { api('/api/dashboard', { auth: true }).then(setD).catch(() => {}); }, []);
  if (!d) return <Shell><p>Carregando…</p></Shell>;
  const max = Math.max(...d.funnel.map((f) => f.value || 1), 1);
  return (
    <Shell>
      <p className="kicker">Painel</p>
      <h2 className="serif" style={{ fontSize: 36 }}>Receita, prazos e captação</h2>
      <div className="kpis">
        <div className="kpi"><b>{money(d.kpis.mrr)}</b><span>MRR de retainers</span></div>
        <div className="kpi"><b>{money(d.kpis.arr)}</b><span>ARR projetado</span></div>
        <div className="kpi"><b>{money(d.kpis.pipeline)}</b><span>Pipeline comercial</span></div>
        <div className="kpi"><b>{d.kpis.clients}</b><span>Clientes ativos</span></div>
      </div>
      <div className="split">
        <div className="panel">
          <h3>Funil de captação</h3>
          <div className="funnel">
            {d.funnel.map((f) => (
              <div className="funnel-row" key={f.stage}>
                <span>{f.stage}</span>
                <div className="bar"><i style={{ width: `${Math.max(8, (f.value / max) * 100)}%` }} /></div>
                <span>{money(f.value)}</span>
              </div>
            ))}
          </div>
        </div>
        <div className="panel">
          <h3>Atividade</h3>
          {d.activities.map((a) => (
            <p key={a.id} style={{ marginBottom: 10, fontSize: 14 }}><span className="gold">{dt(a.at)}</span> · {a.text}</p>
          ))}
        </div>
      </div>
      <div className="panel">
        <h3>Prazos processuais</h3>
        <table>
          <thead><tr><th>Processo</th><th>Cliente</th><th>Prazo</th><th>Fase</th></tr></thead>
          <tbody>
            {d.cases.map((c) => (
              <tr key={c.id}>
                <td>{c.number}<br /><span className="muted">{c.title}</span></td>
                <td>{c.clientName}</td>
                <td className="warn">{day(c.deadline)}</td>
                <td>{c.phase}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </Shell>
  );
}

function Leads() {
  const [items, setItems] = useState([]);
  const [form, setForm] = useState({ name: '', email: '', phone: '', interest: '', value: '', source: 'manual' });
  async function load() {
    const res = await api('/api/leads', { auth: true });
    setItems(res.items);
  }
  useEffect(() => { load(); }, []);
  async function add(e) {
    e.preventDefault();
    await api('/api/leads', { method: 'POST', auth: true, body: { ...form, value: Number(form.value || 0) } });
    setForm({ name: '', email: '', phone: '', interest: '', value: '', source: 'manual' });
    load();
  }
  async function move(id, stage) {
    await api(`/api/leads/${id}`, { method: 'PATCH', auth: true, body: { stage } });
    load();
  }
  return (
    <Shell>
      <h2 className="serif" style={{ fontSize: 34 }}>Captação de clientes</h2>
      <form className="toolbar" onSubmit={add}>
        <input required placeholder="Nome" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
        <input placeholder="E-mail" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
        <input placeholder="Interesse" value={form.interest} onChange={(e) => setForm({ ...form, interest: e.target.value })} />
        <input placeholder="Valor" value={form.value} onChange={(e) => setForm({ ...form, value: e.target.value })} />
        <button className="btn sm" type="submit">Novo lead</button>
      </form>
      <div className="panel">
        <table>
          <thead><tr><th>Lead</th><th>Origem</th><th>Estágio</th><th>Valor</th><th></th></tr></thead>
          <tbody>
            {items.map((l) => (
              <tr key={l.id}>
                <td>{l.name}<br /><span className="muted">{l.email} · {l.interest}</span></td>
                <td>{l.source}</td>
                <td><span className="badge warn">{l.stage}</span></td>
                <td>{money(l.value)}</td>
                <td>
                  <select value={l.stage} onChange={(e) => move(l.id, e.target.value)}>
                    {['novo', 'qualificado', 'proposta', 'negociacao', 'ganho', 'perdido'].map((s) => <option key={s}>{s}</option>)}
                  </select>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </Shell>
  );
}

function Clientes() {
  const [items, setItems] = useState([]);
  const [form, setForm] = useState({ name: '', email: '', plan: 'empresarial', monthlyFee: 14800, segment: '' });
  async function load() {
    const res = await api('/api/clients', { auth: true });
    setItems(res.items);
  }
  useEffect(() => { load(); }, []);
  async function add(e) {
    e.preventDefault();
    await api('/api/clients', { method: 'POST', auth: true, body: form });
    load();
  }
  const mrr = items.filter((c) => c.status === 'ativo').reduce((s, c) => s + c.monthlyFee, 0);
  return (
    <Shell>
      <h2 className="serif" style={{ fontSize: 34 }}>Clientes e retainers</h2>
      <p className="muted">MRR atual: {money(mrr)}</p>
      <form className="toolbar" onSubmit={add}>
        <input required placeholder="Cliente" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
        <input placeholder="E-mail" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
        <input placeholder="Segmento" value={form.segment} onChange={(e) => setForm({ ...form, segment: e.target.value })} />
        <input placeholder="Mensalidade" value={form.monthlyFee} onChange={(e) => setForm({ ...form, monthlyFee: Number(e.target.value) })} />
        <button className="btn sm">Cadastrar</button>
      </form>
      <div className="panel">
        <table>
          <thead><tr><th>Cliente</th><th>Plano</th><th>Mensalidade</th><th>Desde</th><th>Sócio</th></tr></thead>
          <tbody>
            {items.map((c) => (
              <tr key={c.id}>
                <td>{c.name}<br /><span className="muted">{c.segment}</span></td>
                <td>{c.plan}</td>
                <td>{money(c.monthlyFee)}</td>
                <td>{c.since}</td>
                <td>{c.owner}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </Shell>
  );
}

function Processos() {
  const [items, setItems] = useState([]);
  const [form, setForm] = useState({ number: '', title: '', clientName: '', court: '', deadline: '', area: 'Cível' });
  async function load() {
    const res = await api('/api/cases', { auth: true });
    setItems(res.items);
  }
  useEffect(() => { load(); }, []);
  async function add(e) {
    e.preventDefault();
    await api('/api/cases', { method: 'POST', auth: true, body: form });
    load();
  }
  return (
    <Shell>
      <h2 className="serif" style={{ fontSize: 34 }}>Acompanhamento processual</h2>
      <form className="toolbar" onSubmit={add}>
        <input required placeholder="Número CNJ" value={form.number} onChange={(e) => setForm({ ...form, number: e.target.value })} />
        <input required placeholder="Título" value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} />
        <input placeholder="Cliente" value={form.clientName} onChange={(e) => setForm({ ...form, clientName: e.target.value })} />
        <input type="date" value={form.deadline} onChange={(e) => setForm({ ...form, deadline: e.target.value })} />
        <button className="btn sm">Incluir</button>
      </form>
      <div className="panel">
        <table>
          <thead><tr><th>Autos</th><th>Cliente</th><th>Órgão</th><th>Status</th><th>Prazo</th></tr></thead>
          <tbody>
            {items.map((c) => (
              <tr key={c.id}>
                <td>{c.number}<br /><span className="muted">{c.title}<br />{c.lastMove}</span></td>
                <td>{c.clientName}</td>
                <td>{c.court}</td>
                <td><span className="badge ok">{c.status}</span></td>
                <td className="warn">{c.deadline}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </Shell>
  );
}

function Agenda() {
  const [items, setItems] = useState([]);
  const [form, setForm] = useState({ title: '', with: '', date: '', type: 'cliente', location: 'Escritório' });
  async function load() {
    const res = await api('/api/appointments', { auth: true });
    setItems(res.items);
  }
  useEffect(() => { load(); }, []);
  async function add(e) {
    e.preventDefault();
    await api('/api/appointments', { method: 'POST', auth: true, body: form });
    load();
  }
  return (
    <Shell>
      <h2 className="serif" style={{ fontSize: 34 }}>Agenda da banca</h2>
      <form className="toolbar" onSubmit={add}>
        <input required placeholder="Compromisso" value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} />
        <input placeholder="Com" value={form.with} onChange={(e) => setForm({ ...form, with: e.target.value })} />
        <input type="datetime-local" value={form.date} onChange={(e) => setForm({ ...form, date: e.target.value })} />
        <button className="btn sm">Agendar</button>
      </form>
      <div className="panel">
        {items.map((a) => (
          <p key={a.id} style={{ marginBottom: 12 }}><strong>{dt(a.date)}</strong> · {a.title} — {a.with} ({a.location})</p>
        ))}
      </div>
    </Shell>
  );
}

function Financeiro() {
  const [items, setItems] = useState([]);
  async function load() {
    const res = await api('/api/invoices', { auth: true });
    setItems(res.items);
  }
  useEffect(() => { load(); }, []);
  async function pay(id) {
    await api(`/api/invoices/${id}/pay`, { method: 'POST', auth: true });
    load();
  }
  return (
    <Shell>
      <h2 className="serif" style={{ fontSize: 34 }}>Financeiro</h2>
      <div className="panel">
        <table>
          <thead><tr><th>Descrição</th><th>Cliente</th><th>Valor</th><th>Status</th><th></th></tr></thead>
          <tbody>
            {items.map((i) => (
              <tr key={i.id}>
                <td>{i.description}</td>
                <td>{i.clientName}</td>
                <td>{money(i.amount)}</td>
                <td className={i.status === 'pago' ? 'ok' : 'warn'}>{i.status}</td>
                <td>{i.status !== 'pago' && <button className="btn sm" onClick={() => pay(i.id)}>Baixar</button>}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </Shell>
  );
}

function Canais() {
  const [items, setItems] = useState([]);
  async function load() {
    const res = await api('/api/messages', { auth: true });
    setItems(res.items);
  }
  useEffect(() => { load(); }, []);
  async function close(id) {
    await api(`/api/messages/${id}`, { method: 'PATCH', auth: true, body: { status: 'fechado' } });
    load();
  }
  return (
    <Shell>
      <h2 className="serif" style={{ fontSize: 34 }}>Caixa unificada — site, e-mail e WhatsApp</h2>
      <div className="panel">
        {items.map((m) => (
          <article key={m.id} style={{ borderBottom: '1px solid #2a3632', padding: '12px 0' }}>
            <p><span className="badge">{m.channel}</span> {m.from} · {m.contact} {m.autoReplied && <span className="ok"> · auto-respondido</span>}</p>
            <strong>{m.subject}</strong>
            <p className="muted">{m.body}</p>
            {m.status !== 'fechado' && <button className="btn sm" style={{ marginTop: 8 }} onClick={() => close(m.id)}>Encerrar</button>}
          </article>
        ))}
      </div>
    </Shell>
  );
}

function Automacoes() {
  const [data, setData] = useState({ items: [], logs: [] });
  async function load() {
    setData(await api('/api/automations', { auth: true }));
  }
  useEffect(() => { load(); }, []);
  async function toggle(a) {
    await api(`/api/automations/${a.id}`, { method: 'PATCH', auth: true, body: { active: !a.active } });
    load();
  }
  async function run(id) {
    await api('/api/automations/run', { method: 'POST', auth: true, body: { automationId: id, vars: { nome: 'Cliente teste' } } });
    load();
  }
  return (
    <Shell>
      <h2 className="serif" style={{ fontSize: 34 }}>Automações de resposta</h2>
      {data.items.map((a) => (
        <div className="panel" key={a.id}>
          <h3>{a.name} <span className="muted">· {a.channel}</span></h3>
          <p className="muted" style={{ whiteSpace: 'pre-wrap' }}>{a.template}</p>
          <p style={{ marginTop: 10 }}>
            <button className="btn sm" onClick={() => toggle(a)}>{a.active ? 'Desativar' : 'Ativar'}</button>
            {' '}
            <button className="btn sm ghost" onClick={() => run(a.id)}>Disparar teste</button>
          </p>
        </div>
      ))}
      <div className="panel">
        <h3>Logs</h3>
        {data.logs.map((l) => (
          <p key={l.id} style={{ fontSize: 13, marginBottom: 8 }}>{dt(l.createdAt)} · {l.channel} → {l.target} · {l.preview}</p>
        ))}
      </div>
    </Shell>
  );
}

function AdminJuris() {
  const [q, setQ] = useState('pejotização');
  const [data, setData] = useState(null);
  const [kw, setKw] = useState('');
  async function load(query = q) {
    setData(await api(`/api/jurisprudence?q=${encodeURIComponent(query)}`, { auth: true }));
  }
  useEffect(() => { load(); }, []);
  async function watch(e) {
    e.preventDefault();
    await api('/api/watchlists', { method: 'POST', auth: true, body: { keyword: kw } });
    setKw('');
    load();
  }
  return (
    <Shell>
      <h2 className="serif" style={{ fontSize: 34 }}>Radar de jurisprudência</h2>
      <form className="toolbar" onSubmit={(e) => { e.preventDefault(); load(); }}>
        <input value={q} onChange={(e) => setQ(e.target.value)} />
        <button className="btn sm">Atualizar</button>
      </form>
      <div className="split">
        <div>
          {(data?.items || []).map((i) => (
            <div className="panel" key={i.id}>
              <p className="gold">{i.court} · {i.number}</p>
              <h3>{i.title}</h3>
              <p className="muted">{i.ementa}</p>
              <a href={i.sourceUrl} target="_blank" rel="noreferrer">Fonte oficial</a>
            </div>
          ))}
        </div>
        <div>
          <div className="panel">
            <h3>Watchlists</h3>
            <form className="toolbar" onSubmit={watch}>
              <input value={kw} onChange={(e) => setKw(e.target.value)} placeholder="Nova tese monitorada" />
              <button className="btn sm">Monitorar</button>
            </form>
            {(data?.watchlists || []).map((w) => (
              <p key={w.id}>{w.keyword} · {w.courts.join(', ')} · {w.hits} hits</p>
            ))}
          </div>
        </div>
      </div>
    </Shell>
  );
}

function Config() {
  const [s, setS] = useState(null);
  useEffect(() => { api('/api/settings', { auth: true }).then(setS); }, []);
  if (!s) return <Shell><p>Carregando…</p></Shell>;
  return (
    <Shell>
      <h2 className="serif" style={{ fontSize: 34 }}>Configurações</h2>
      <div className="panel">
        <h3>Escritório</h3>
        <p>{s.firm.name}<br />{s.firm.address}<br />{s.firm.phone}<br />{s.firm.email}</p>
      </div>
      <div className="panel">
        <h3>Canais conectados</h3>
        <p>SMTP {s.smtp.host} · {s.smtp.configured ? 'ativo' : 'pendente'}</p>
        <p>WhatsApp oficial {s.whatsappApi.number} · {s.whatsappApi.configured ? 'ativo' : 'pendente'}</p>
        <p>Redes: {Object.keys(s.social).join(' · ')}</p>
      </div>
    </Shell>
  );
}

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/jurisprudencia" element={<Jurisprudencia />} />
      <Route path="/contato" element={<Contato />} />
      <Route path="/admin/login" element={<Login />} />
      <Route path="/admin" element={<RequireAuth><Dashboard /></RequireAuth>} />
      <Route path="/admin/leads" element={<RequireAuth><Leads /></RequireAuth>} />
      <Route path="/admin/clientes" element={<RequireAuth><Clientes /></RequireAuth>} />
      <Route path="/admin/processos" element={<RequireAuth><Processos /></RequireAuth>} />
      <Route path="/admin/agenda" element={<RequireAuth><Agenda /></RequireAuth>} />
      <Route path="/admin/financeiro" element={<RequireAuth><Financeiro /></RequireAuth>} />
      <Route path="/admin/canais" element={<RequireAuth><Canais /></RequireAuth>} />
      <Route path="/admin/automacoes" element={<RequireAuth><Automacoes /></RequireAuth>} />
      <Route path="/admin/jurisprudencia" element={<RequireAuth><AdminJuris /></RequireAuth>} />
      <Route path="/admin/config" element={<RequireAuth><Config /></RequireAuth>} />
    </Routes>
  );
}
