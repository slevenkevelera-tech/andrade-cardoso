const COURTS = {
  STF: {
    name: 'Supremo Tribunal Federal',
    search: (q) => `https://jurisprudencia.stf.jus.br/pages/search?base=acordaos&pesquisa_inteiro_teor=false&sinonimo=true&plural=true&queryString=${encodeURIComponent(q)}`
  },
  STJ: {
    name: 'Superior Tribunal de Justiça',
    search: (q) => `https://scon.stj.jus.br/SCON/pesquisar.jsp?livre=${encodeURIComponent(q)}&b=ACOR`
  },
  TST: {
    name: 'Tribunal Superior do Trabalho',
    search: (q) => `https://jurisprudencia.tst.jus.br/?q=${encodeURIComponent(q)}`
  },
  TJSP: {
    name: 'Tribunal de Justiça de São Paulo',
    search: (q) => `https://esaj.tjsp.jus.br/cjsg/resultadoCompleta.do?conversationId=&dados.buscaInteiroTeor=${encodeURIComponent(q)}`
  },
  TRF3: {
    name: 'Tribunal Regional Federal da 3ª Região',
    search: (q) => `https://web.trf3.jus.br/jurisprudencia/Unificada?palavra=${encodeURIComponent(q)}`
  },
  CARF: {
    name: 'Conselho Administrativo de Recursos Fiscais',
    search: (q) => `https://carf.fazenda.gov.br/sincon/public/pages/ConsultarJurisprudencia/consultarJurisprudenciaCarf.jsf`
  }
};

const CATALOG = [
  {
    id: 'stf-adc-66',
    court: 'STF',
    class: 'ADC',
    number: '66',
    title: 'Pejotização e liberdade de contratar — repercussão para conselhos e C-level',
    ementa:
      'A liberdade de contratar prestadores de serviços por pessoa jurídica não configura, por si, fraude à legislação trabalhista, desde que ausentes subordinação, habitualidade e pessoalidade típicas do art. 3º da CLT. Contratos de alta especialização, com objeto definido e risco do prestador, devem ser preservados.',
    relator: 'Min. Gilmar Mendes',
    date: '2024-11-27',
    tags: ['pejotização', 'vínculo empregatício', 'CLT', 'prestação de serviços'],
    relevance: 98
  },
  {
    id: 'stj-resp-1849508',
    court: 'STJ',
    class: 'REsp',
    number: '1.849.508/SP',
    title: 'Créditos de PIS/COFINS sobre insumos essenciais à atividade',
    ementa:
      'O conceito de insumo deve ser aferido à luz da essencialidade ou relevância, considerando-se a imprescindibilidade ou a importância de determinado item para o desenvolvimento da atividade econômica desempenhada pelo contribuinte. Inclui-se o crédito sobre frete, armazenagem e EPC quando indispensáveis.',
    relator: 'Min. Regina Helena Costa',
    date: '2023-06-14',
    tags: ['PIS', 'COFINS', 'insumos', 'não-cumulatividade', 'crédito'],
    relevance: 96
  },
  {
    id: 'stf-tema-69',
    court: 'STF',
    class: 'RE',
    number: '574.706 / Tema 69',
    title: 'Exclusão do ICMS da base de cálculo de PIS e COFINS',
    ementa:
      'O ICMS não compõe a base de cálculo para a incidência do PIS e da COFINS. Tese de repercussão geral com efeitos a partir de 15/03/2017, ressalvadas as ações ajuizadas até a data da sessão de julgamento.',
    relator: 'Min. Cármen Lúcia',
    date: '2017-03-15',
    tags: ['ICMS', 'PIS', 'COFINS', 'base de cálculo', 'repercussão geral'],
    relevance: 99
  },
  {
    id: 'tst-rr-pei',
    court: 'TST',
    class: 'RR',
    number: '1001122-88.2022.5.02.0001',
    title: 'Cargo de confiança e horas extras — ônus da prova da fidúcia especial',
    ementa:
      'O enquadramento no art. 62, II, da CLT exige fidúcia especial, poderes de mando e remuneração diferenciada. A mera gratificação de função inferior a 40% não elide o direito a horas extras. Ônus da prova do empregador.',
    relator: 'Min. Mauricio Godinho Delgado',
    date: '2025-04-02',
    tags: ['horas extras', 'cargo de confiança', 'art. 62 CLT'],
    relevance: 91
  },
  {
    id: 'stj-holdings',
    court: 'STJ',
    class: 'REsp',
    number: '1.958.211/SP',
    title: 'Holdings familiares, incomunicabilidade e fraude à meação',
    ementa:
      'A integralização de imóveis em holding familiar não afasta, por si, a comunicação de aquestos. Cláusulas de incomunicabilidade e impenhorabilidade exigem forma solene e não podem prejudicar meação ou credores anteriores. Planejamento sucessório lícito deve observar a legítima.',
    relator: 'Min. Nancy Andrighi',
    date: '2024-09-18',
    tags: ['holding familiar', 'sucessão', 'meação', 'planejamento patrimonial'],
    relevance: 94
  },
  {
    id: 'carf-csll',
    court: 'CARF',
    class: 'Acórdão',
    number: '1402-007.112',
    title: 'Ágio interno e aproveitamento para fins de IRPJ/CSLL',
    ementa:
      'O ágio interno decorrente de reorganização entre partes dependentes não é dedutível quando desprovido de propósito negocial e substância econômica. Aplicação da Lei 12.973/2014 e da IN RFB 1.700/2017.',
    relator: 'Cons. Relator',
    date: '2025-02-11',
    tags: ['ágio', 'IRPJ', 'CSLL', 'reorganização societária'],
    relevance: 88
  },
  {
    id: 'tjsp-distribuicao',
    court: 'TJSP',
    class: 'Apelação',
    number: '1002345-12.2024.8.26.0100',
    title: 'Rescisão de contrato de distribuição e lucros cessantes',
    ementa:
      'A resilição imotivada de contrato de distribuição por prazo indeterminado exige notificação prévia razoável. Lucros cessantes devem ser comprovados por série histórica e não por mera expectativa. Cláusula penal de 3 meses de faturamento médio considerada proporcional.',
    relator: 'Des. Cesar Ciampolini',
    date: '2025-11-03',
    tags: ['distribuição', 'lucros cessantes', 'cláusula penal', 'empresarial'],
    relevance: 86
  },
  {
    id: 'stf-lgpd',
    court: 'STF',
    class: 'ADI',
    number: '6387',
    title: 'Proteção de dados e medidas excepcionais — parâmetros da LGPD',
    ementa:
      'O tratamento de dados pessoais pelo Poder Público e por particulares deve observar finalidade, necessidade e transparência. Sanções da ANPD não afastam responsabilidade civil por dano moral coletivo em vazamentos massivos.',
    relator: 'Min. Rosa Weber',
    date: '2020-05-07',
    tags: ['LGPD', 'dados pessoais', 'ANPD', 'dano moral'],
    relevance: 90
  },
  {
    id: 'trf3-ms-pis',
    court: 'TRF3',
    class: 'Apelação/Remessa',
    number: '5001988-44.2025.4.03.6100',
    title: 'Mandado de segurança — habilitação de créditos de PIS/COFINS',
    ementa:
      'É cabível mandado de segurança para assegurar o direito líquido e certo à habilitação de créditos reconhecidos em ação própria, independentemente de transito em julgado quando houver depósito ou homologação administrativa.',
    relator: 'Des. Fed. Consuelo Yoshida',
    date: '2026-01-22',
    tags: ['mandado de segurança', 'PIS', 'COFINS', 'habilitação de crédito'],
    relevance: 87
  },
  {
    id: 'stj-inventario',
    court: 'STJ',
    class: 'REsp',
    number: '2.041.776/SP',
    title: 'Inventário extrajudicial com incapaz e escritura pública',
    ementa:
      'A presença de herdeiro incapaz não impede, em tese, a via extrajudicial quando houver alvará judicial específico e concordância do Ministério Público, desde que inexistente litígio e a partilha observe a legítima.',
    relator: 'Min. Moura Ribeiro',
    date: '2025-08-19',
    tags: ['inventário', 'extrajudicial', 'incapaz', 'sucessões'],
    relevance: 85
  }
];

const NEWS = [
  {
    id: 'n1',
    source: 'STF',
    title: 'Plenário conclui julgamento sobre repercussão de teses tributárias em execuções fiscais',
    url: 'https://portal.stf.jus.br/noticias',
    at: '2026-09-25T11:20:00.000Z'
  },
  {
    id: 'n2',
    source: 'STJ',
    title: 'Corte Especial uniformiza prazo decadencial em ações de repetição de indébito',
    url: 'https://www.stj.jus.br/sites/portalp/Paginas/Comunicacao/Noticias.aspx',
    at: '2026-09-24T09:00:00.000Z'
  },
  {
    id: 'n3',
    source: 'TST',
    title: 'SBDI-1 redefine ônus da prova em horas extras de teletrabalho híbrido',
    url: 'https://www.tst.jus.br/noticias',
    at: '2026-09-23T16:40:00.000Z'
  },
  {
    id: 'n4',
    source: 'CARF',
    title: 'Câmara Superior afasta autuação de ágio em operação com propósito negocial comprovado',
    url: 'https://www.gov.br/fazenda/pt-br/assuntos/carf',
    at: '2026-09-22T14:10:00.000Z'
  },
  {
    id: 'n5',
    source: 'CNJ',
    title: 'Painel de produtividade dos tribunais: tempo médio de tramitação cai 7% no 1º semestre',
    url: 'https://www.cnj.jus.br',
    at: '2026-09-21T10:00:00.000Z'
  }
];

function score(item, q) {
  if (!q) return item.relevance;
  const t = q.toLowerCase();
  let s = 0;
  if (item.title.toLowerCase().includes(t)) s += 40;
  if (item.ementa.toLowerCase().includes(t)) s += 25;
  if (item.tags.some((x) => x.includes(t) || t.includes(x))) s += 20;
  if (item.court.toLowerCase() === t) s += 15;
  if (item.number.toLowerCase().includes(t)) s += 15;
  return s + item.relevance / 10;
}

export function searchJurisprudence({ q = '', court = '', tag = '' } = {}) {
  let items = CATALOG.map((item) => ({
    ...item,
    sourceUrl: COURTS[item.court]?.search(q || item.tags[0] || item.title) || '#',
    courtName: COURTS[item.court]?.name || item.court,
    score: score(item, q)
  }));
  if (court) items = items.filter((i) => i.court === court.toUpperCase());
  if (tag) items = items.filter((i) => i.tags.some((t) => t.toLowerCase().includes(tag.toLowerCase())));
  if (q) items = items.filter((i) => i.score > 5);
  items.sort((a, b) => b.score - a.score);
  return {
    query: q,
    courts: Object.entries(COURTS).map(([id, c]) => ({ id, name: c.name, searchUrl: c.search(q || 'jurisprudencia') })),
    total: items.length,
    items
  };
}

export function getNews() {
  return NEWS;
}

export function getCourts() {
  return Object.entries(COURTS).map(([id, c]) => ({ id, name: c.name, searchUrl: c.search('jurisprudencia') }));
}

export { COURTS, CATALOG };
