import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import crypto from 'crypto';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DATA_DIR = path.join(__dirname, '..', 'data');
const DB_PATH = path.join(DATA_DIR, 'db.json');

function uid(prefix = 'id') {
  return `${prefix}_${crypto.randomBytes(6).toString('hex')}`;
}

function hash(password) {
  return crypto.createHash('sha256').update(`acadv:${password}`).digest('hex');
}

function now() {
  return new Date().toISOString();
}

const empty = {
  users: [],
  leads: [],
  clients: [],
  cases: [],
  appointments: [],
  invoices: [],
  retainers: [],
  messages: [],
  automations: [],
  automationLogs: [],
  watchlists: [],
  jurisprudenceCache: [],
  newsCache: [],
  posts: [],
  settings: {},
  activities: []
};

function seed() {
  const created = now();
  return {
    users: [
      {
        id: 'usr_admin',
        name: 'Maurilo Andrade Cardoso',
        email: 'zoe.m@example.net',
        password: hash('admin123'),
        role: 'socio',
        oab: 'OAB/PA 00.000',
        phone: '(91) 99189-0658',
        avatar: 'MAC',
        createdAt: created
      },
      {
        id: 'usr_helena',
        name: 'Lorenzo Cardoso',
        email: 'zoe.m@example.net',
        password: hash('admin123'),
        role: 'engenharia',
        oab: 'Engenheiro de Software / Ciência de dados',
        phone: '(91) 99189-0658',
        avatar: 'LC',
        createdAt: created
      }
    ],
    leads: [
      {
        id: uid('ld'),
        name: 'Mariana Alves',
        company: 'Alves & Costa Ltda',
        email: 'hannah.h@example.com',
        phone: '+55 11 98812-4401',
        source: 'site',
        stage: 'qualificado',
        interest: 'Assessoria empresarial mensal',
        value: 8500,
        notes: 'Interessada no plano Empresarial. Reunião agendada.',
        createdAt: created,
        updatedAt: created
      },
      {
        id: uid('ld'),
        name: 'Paulo Mendes',
        company: 'Mendes Logística S.A.',
        email: 'bob.m@example.net',
        phone: '+55 11 97654-1120',
        source: 'linkedin',
        stage: 'proposta',
        interest: 'Contencioso tributário + retainer',
        value: 24000,
        notes: 'Proposta enviada. Decisão até sexta.',
        createdAt: created,
        updatedAt: created
      },
      {
        id: uid('ld'),
        name: 'Carla Nogueira',
        company: '',
        email: 'xavier.y@example.org',
        phone: '+55 21 99120-7788',
        source: 'whatsapp',
        stage: 'novo',
        interest: 'Inventário e planejamento sucessório',
        value: 12000,
        notes: 'Primeiro contato via WhatsApp.',
        createdAt: created,
        updatedAt: created
      },
      {
        id: uid('ld'),
        name: 'TechNova Sistemas',
        company: 'TechNova Sistemas Ltda',
        email: 'ursula.b@example.com',
        phone: '+55 11 4002-8890',
        source: 'indicacao',
        stage: 'negociacao',
        interest: 'LGPD + contratos de SaaS',
        value: 18000,
        notes: 'Indicação do cliente Horizonte Capital.',
        createdAt: created,
        updatedAt: created
      },
      {
        id: uid('ld'),
        name: 'Roberto Farias',
        company: 'Farias Incorporadora',
        email: 'samuel.w@example.com',
        phone: '+55 11 98200-3344',
        source: 'instagram',
        stage: 'ganho',
        interest: 'Due diligence imobiliária',
        value: 32000,
        notes: 'Convertido para cliente. Honorários iniciais pagos.',
        createdAt: created,
        updatedAt: created
      }
    ],
    clients: [
      {
        id: 'cli_horizonte',
        name: 'Horizonte Capital',
        type: 'pj',
        document: '14.882.331/0001-90',
        email: 'olivia.t@example.org',
        phone: '+55 11 3030-4400',
        segment: 'Investimentos',
        plan: 'premium',
        monthlyFee: 28500,
        status: 'ativo',
        since: '2019-03-12',
        owner: 'Ricardo Andrade',
        createdAt: created
      },
      {
        id: 'cli_aurora',
        name: 'Aurora Farma',
        type: 'pj',
        document: '08.441.902/0001-55',
        email: 'ursula.b@example.com',
        phone: '+55 11 3099-1200',
        segment: 'Saúde',
        plan: 'empresarial',
        monthlyFee: 14200,
        status: 'ativo',
        since: '2021-07-01',
        owner: 'Helena Cardoso',
        createdAt: created
      },
      {
        id: 'cli_silva',
        name: 'Família Silva Prado',
        type: 'pf',
        document: '***.***.***-**',
        email: 'xena.w@example.org',
        phone: '+55 11 99610-2211',
        segment: 'Família e Sucessões',
        plan: 'essencial',
        monthlyFee: 4800,
        status: 'ativo',
        since: '2022-11-18',
        owner: 'Helena Cardoso',
        createdAt: created
      },
      {
        id: 'cli_norte',
        name: 'Norte Sul Indústria',
        type: 'pj',
        document: '22.109.774/0001-02',
        email: 'iris.p@example.org',
        phone: '+55 19 3444-8000',
        segment: 'Indústria',
        plan: 'empresarial',
        monthlyFee: 19800,
        status: 'ativo',
        since: '2020-01-09',
        owner: 'Ricardo Andrade',
        createdAt: created
      }
    ],
    cases: [
      {
        id: uid('cs'),
        number: '1002345-12.2024.8.26.0100',
        title: 'Ação de cobrança — contratos de distribuição',
        clientId: 'cli_aurora',
        clientName: 'Aurora Farma',
        court: 'TJSP — 15ª Vara Cível Central',
        area: 'Cível / Empresarial',
        status: 'em_andamento',
        phase: 'instrução',
        value: 1850000,
        responsible: 'Ricardo Andrade',
        deadline: '2026-10-08',
        lastMove: 'Juntada de laudo pericial. Prazo para manifestação: 15 dias.',
        createdAt: created
      },
      {
        id: uid('cs'),
        number: '5001988-44.2025.4.03.6100',
        title: 'Mandado de segurança — créditos PIS/COFINS',
        clientId: 'cli_norte',
        clientName: 'Norte Sul Indústria',
        court: 'TRF-3 — 6ª Vara Federal de São Paulo',
        area: 'Tributário',
        status: 'em_andamento',
        phase: 'sentenca',
        value: 4200000,
        responsible: 'Helena Cardoso',
        deadline: '2026-10-02',
        lastMove: 'Conclusos para sentença.',
        createdAt: created
      },
      {
        id: uid('cs'),
        number: 'TST-RR-112233-77.2023.5.02.0001',
        title: 'Recurso de revista — horas extras e cargo de confiança',
        clientId: 'cli_horizonte',
        clientName: 'Horizonte Capital',
        court: 'TST — 4ª Turma',
        area: 'Trabalhista',
        status: 'recurso',
        phase: 'recurso',
        value: 640000,
        responsible: 'Ricardo Andrade',
        deadline: '2026-09-30',
        lastMove: 'Pauta de julgamento publicada.',
        createdAt: created
      },
      {
        id: uid('cs'),
        number: '0004412-90.2025.8.26.0100',
        title: 'Inventário — espólio Silva Prado',
        clientId: 'cli_silva',
        clientName: 'Família Silva Prado',
        court: 'TJSP — 2ª Vara de Família e Sucessões',
        area: 'Família e Sucessões',
        status: 'em_andamento',
        phase: 'avaliacao',
        value: 9800000,
        responsible: 'Helena Cardoso',
        deadline: '2026-10-15',
        lastMove: 'Aguardando laudo de avaliação dos imóveis.',
        createdAt: created
      }
    ],
    appointments: [
      {
        id: uid('ap'),
        title: 'Reunião — plano Empresarial Alves & Costa',
        with: 'Mariana Alves',
        type: 'captacao',
        date: '2026-09-29T14:00:00.000Z',
        duration: 60,
        location: 'Sala de reuniões — Av. Faria Lima',
        status: 'agendado'
      },
      {
        id: uid('ap'),
        title: 'Audiência de instrução — Aurora Farma',
        with: '15ª Vara Cível Central',
        type: 'audiencia',
        date: '2026-10-08T13:00:00.000Z',
        duration: 120,
        location: 'Fórum João Mendes Jr.',
        status: 'agendado'
      },
      {
        id: uid('ap'),
        title: 'Comité tributário — Norte Sul',
        with: 'Diretoria Norte Sul Indústria',
        type: 'cliente',
        date: '2026-09-30T16:30:00.000Z',
        duration: 90,
        location: 'Videoconferência',
        status: 'agendado'
      }
    ],
    invoices: [
      {
        id: uid('inv'),
        clientId: 'cli_horizonte',
        clientName: 'Horizonte Capital',
        description: 'Retainer Premium — setembro/2026',
        amount: 28500,
        status: 'pago',
        dueDate: '2026-09-10',
        paidAt: '2026-09-08',
        type: 'retainer'
      },
      {
        id: uid('inv'),
        clientId: 'cli_aurora',
        clientName: 'Aurora Farma',
        description: 'Retainer Empresarial — setembro/2026',
        amount: 14200,
        status: 'pago',
        dueDate: '2026-09-10',
        paidAt: '2026-09-09',
        type: 'retainer'
      },
      {
        id: uid('inv'),
        clientId: 'cli_norte',
        clientName: 'Norte Sul Indústria',
        description: 'Retainer Empresarial — setembro/2026',
        amount: 19800,
        status: 'pendente',
        dueDate: '2026-09-30',
        paidAt: null,
        type: 'retainer'
      },
      {
        id: uid('inv'),
        clientId: 'cli_silva',
        clientName: 'Família Silva Prado',
        description: 'Assessoria Essencial — setembro/2026',
        amount: 4800,
        status: 'pago',
        dueDate: '2026-09-10',
        paidAt: '2026-09-05',
        type: 'retainer'
      },
      {
        id: uid('inv'),
        clientId: 'cli_horizonte',
        clientName: 'Horizonte Capital',
        description: 'Êxito — acordo trabalhista',
        amount: 42000,
        status: 'pago',
        dueDate: '2026-09-20',
        paidAt: '2026-09-18',
        type: 'exito'
      }
    ],
    retainers: [
      {
        id: 'pl_essencial',
        name: 'Essencial',
        price: 4800,
        cycle: 'mensal',
        features: ['Plantão jurídico 8h–18h', 'Até 8 consultas/mês', 'Revisão de 4 contratos', 'Alertas de prazos']
      },
      {
        id: 'pl_empresarial',
        name: 'Empresarial',
        price: 14800,
        cycle: 'mensal',
        features: ['Sócio dedicado', 'Até 20 consultas/mês', 'Contencioso estratégico', 'Compliance trabalhista e tributário', 'Relatório mensal']
      },
      {
        id: 'pl_premium',
        name: 'Premium / Family Office',
        price: 28500,
        cycle: 'mensal',
        features: ['Banca 24/7', 'Mesa de crise', 'M&A e sucessão', 'LGPD e regulatório', 'Board jurídico trimestral']
      }
    ],
    messages: [
      {
        id: uid('msg'),
        channel: 'site',
        from: 'Mariana Alves',
        contact: 'hannah.h@example.com',
        subject: 'Quero o plano Empresarial',
        body: 'Gostaria de uma proposta de assessoria jurídica contínua para a Alves & Costa.',
        status: 'aberto',
        autoReplied: true,
        createdAt: created
      },
      {
        id: uid('msg'),
        channel: 'whatsapp',
        from: 'Carla Nogueira',
        contact: '+55 21 99120-7788',
        subject: 'Inventário',
        body: 'Boa tarde. Vocês atendem inventário em São Paulo? Meu pai faleceu e precisamos de orientação.',
        status: 'aberto',
        autoReplied: true,
        createdAt: created
      },
      {
        id: uid('msg'),
        channel: 'email',
        from: 'Paulo Mendes',
        contact: 'bob.m@example.net',
        subject: 'Proposta tributária',
        body: 'Recebemos a proposta. Podemos negociar o êxito em 8%?',
        status: 'em_atendimento',
        autoReplied: false,
        createdAt: created
      }
    ],
    automations: [
      {
        id: 'aut_welcome_email',
        name: 'Boas-vindas por e-mail',
        channel: 'email',
        trigger: 'novo_lead',
        active: true,
        delayMinutes: 0,
        template:
          'Prezado(a) {{nome}},\n\nRecebemos sua mensagem no escritório Andrade Cardoso. Um sócio responsável analisará o caso e retornará em até 4 horas úteis.\n\nEnquanto isso, você pode agendar uma consulta inicial em andradecardoso.adv.br/contato.\n\nAtenciosamente,\nAndrade Cardoso Advogados'
      },
      {
        id: 'aut_whatsapp_triagem',
        name: 'Triagem automática WhatsApp',
        channel: 'whatsapp',
        trigger: 'mensagem_whatsapp',
        active: true,
        delayMinutes: 0,
        template:
          'Olá, {{nome}}. Sou a assistente do Andrade Cardoso.\n\nPara agilizar o atendimento, informe:\n1) Área (empresarial, tributário, trabalhista, família, cível)\n2) Urgência (hoje / esta semana / sem prazo)\n3) Cidade\n\nUm advogado responderá em instantes. Plantão: (11) 99900-2200'
      },
      {
        id: 'aut_nurture',
        name: 'Nutrição de leads — D+2',
        channel: 'email',
        trigger: 'lead_sem_resposta',
        active: true,
        delayMinutes: 2880,
        template:
          '{{nome}}, preparamos um briefing com as teses mais recentes do STJ/STF na área de seu interesse. Podemos agendar 20 minutos com o Dr. Ricardo Andrade ou a Dra. Helena Cardoso?'
      },
      {
        id: 'aut_prazo',
        name: 'Alerta de prazo processual',
        channel: 'email',
        trigger: 'prazo_72h',
        active: true,
        delayMinutes: 0,
        template:
          'ALERTA DE PRAZO — processo {{processo}} vence em 72 horas. Responsável: {{responsavel}}. Cliente: {{cliente}}.'
      },
      {
        id: 'aut_inadimplencia',
        name: 'Cobrança amigável de retainer',
        channel: 'email',
        trigger: 'fatura_vencida',
        active: true,
        delayMinutes: 1440,
        template:
          'Prezado(a) {{nome}}, identificamos a fatura {{fatura}} em aberto. Para manter a cobertura do plano {{plano}}, regularize em até 5 dias úteis. Financeiro: emma.t@example.net'
      }
    ],
    automationLogs: [
      {
        id: uid('log'),
        automationId: 'aut_welcome_email',
        channel: 'email',
        target: 'hannah.h@example.com',
        status: 'enviado',
        preview: 'Boas-vindas enviada para Mariana Alves',
        createdAt: created
      },
      {
        id: uid('log'),
        automationId: 'aut_whatsapp_triagem',
        channel: 'whatsapp',
        target: '+55 21 99120-7788',
        status: 'enviado',
        preview: 'Triagem automática enviada para Carla Nogueira',
        createdAt: created
      }
    ],
    watchlists: [
      {
        id: uid('wl'),
        keyword: 'créditos de PIS/COFINS inputs',
        courts: ['STJ', 'STF', 'CARF'],
        active: true,
        hits: 12,
        lastHit: created
      },
      {
        id: uid('wl'),
        keyword: 'pejotização vínculo empregatício',
        courts: ['TST', 'STF'],
        active: true,
        hits: 7,
        lastHit: created
      },
      {
        id: uid('wl'),
        keyword: 'planejamento sucessório holdings',
        courts: ['STJ', 'TJSP'],
        active: true,
        hits: 4,
        lastHit: created
      }
    ],
    jurisprudenceCache: [],
    newsCache: [],
    posts: [
      {
        id: uid('post'),
        title: 'STF e a pejotização: o que muda para conselhos e C-level',
        excerpt: 'Análise da banca sobre os impactos da nova composição de precedentes e como estruturar contratos de prestação sem risco trabalhista.',
        category: 'Trabalhista',
        author: 'Ricardo Andrade',
        publishedAt: '2026-09-12',
        featured: true
      },
      {
        id: uid('post'),
        title: 'Créditos de PIS/COFINS após a Lei 14.592: tese e compliance',
        excerpt: 'Roteiro prático para indústria e atacado recuperarem créditos com segurança e reduzirem autuações.',
        category: 'Tributário',
        author: 'Helena Cardoso',
        publishedAt: '2026-08-28',
        featured: true
      },
      {
        id: uid('post'),
        title: 'Holdings familiares: governança que protege patrimônio e relações',
        excerpt: 'Como combinar acordo de sócios, testamento e cláusulas de incomunicabilidade sem gerar litígio futuro.',
        category: 'Família e Sucessões',
        author: 'Helena Cardoso',
        publishedAt: '2026-08-04',
        featured: false
      }
    ],
    settings: {
      firm: {
        name: 'Andrade Cardoso Advogados',
        tagline: 'Estratégia jurídica. Resultado de sócio.',
        phone: '(91) 99189-0658',
        whatsapp: '5591991890658',
        email: 'andrade.cardosoadv@gmail.com',
        address: 'Rua 15 de Novembro 2442 - São Benedito',
        oab: 'OAB/PA 00.000'
      },
      social: {
        linkedin: 'https://www.linkedin.com/company/andrade-cardoso-advogados',
        instagram: 'https://www.instagram.com/andradecardoso.adv',
        facebook: 'https://www.facebook.com/andradecardosoadvogados',
        youtube: 'https://www.youtube.com/@AndradeCardosoAdv',
        x: 'https://x.com/andradecardoso',
        whatsapp: 'https://wa.me/5591991890658'
      },
      smtp: {
        host: 'smtp.gmail.com',
        port: 587,
        from: 'Andrade Cardoso <andrade.cardosoadv@gmail.com>',
        configured: true
      },
      whatsappApi: {
        provider: 'oficial',
        number: '(91) 99189-0658',
        configured: true
      }
    },
    activities: [
      { id: uid('act'), text: 'Lead Paulo Mendes avançou para Proposta (R$ 24.000)', at: created },
      { id: uid('act'), text: 'Alerta de prazo: TST-RR-112233 vence em 48h', at: created },
      { id: uid('act'), text: 'Retainer Horizonte Capital compensado (R$ 28.500)', at: created },
      { id: uid('act'), text: 'Automação WhatsApp respondeu Carla Nogueira', at: created }
    ]
  };
}

let db;

export function loadDb() {
  if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
  if (!fs.existsSync(DB_PATH)) {
    db = seed();
    saveDb();
  } else {
    db = JSON.parse(fs.readFileSync(DB_PATH, 'utf8'));
  }
  return db;
}

export function saveDb() {
  fs.writeFileSync(DB_PATH, JSON.stringify(db, null, 2));
}

export function getDb() {
  if (!db) loadDb();
  return db;
}

export { uid, hash, now };
