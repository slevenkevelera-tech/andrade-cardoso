import http from 'http';
import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import { fileURLToPath } from 'url';
import { getDb, saveDb, uid, hash, now, loadDb } from './db.js';
import { searchJurisprudence, getNews, getCourts } from './jurisprudence.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PORT = Number(process.env.PORT || 3001);
const sessions = new Map();

loadDb();

function parseBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    req.on('data', (c) => chunks.push(c));
    req.on('end', () => {
      const raw = Buffer.concat(chunks).toString('utf8');
      if (!raw) return resolve({});
      try {
        resolve(JSON.parse(raw));
      } catch {
        resolve({});
      }
    });
    req.on('error', reject);
  });
}

function corsHeaders() {
  return {
    'Access-Control-Allow-Origin': process.env.CORS_ORIGIN || '*',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    'Access-Control-Allow-Methods': 'GET,POST,PUT,PATCH,DELETE,OPTIONS'
  };
}

function send(res, status, data) {
  const body = JSON.stringify(data);
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Length': Buffer.byteLength(body),
    'Cache-Control': 'no-store',
    ...corsHeaders()
  });
  res.end(body);
}

function token() {
  return crypto.randomBytes(24).toString('hex');
}

function auth(req) {
  const h = req.headers.authorization || '';
  const t = h.startsWith('Bearer ') ? h.slice(7) : '';
  if (!t) return null;
  return sessions.get(t) || null;
}

function requireAuth(req, res) {
  const user = auth(req);
  if (!user) {
    send(res, 401, { error: 'Não autenticado' });
    return null;
  }
  return user;
}

function logActivity(text) {
  const db = getDb();
  db.activities.unshift({ id: uid('act'), text, at: now() });
  db.activities = db.activities.slice(0, 40);
  saveDb();
}

function applyTemplate(tpl, vars) {
  return Object.entries(vars).reduce((acc, [k, v]) => acc.replaceAll(`{{${k}}}`, String(v ?? '')), tpl);
}

function runAutomation({ automation, target, vars }) {
  const db = getDb();
  const preview = applyTemplate(automation.template, vars);
  const log = {
    id: uid('log'),
    automationId: automation.id,
    channel: automation.channel,
    target,
    status: 'enviado',
    preview: preview.slice(0, 220),
    createdAt: now()
  };
  db.automationLogs.unshift(log);
  db.automationLogs = db.automationLogs.slice(0, 80);
  saveDb();
  return log;
}

async function handle(req, res) {
  const url = new URL(req.url, `http://${req.headers.host}`);
  const p = url.pathname;
  const m = req.method;

  if (m === 'OPTIONS') {
    res.writeHead(204, corsHeaders());
    return res.end();
  }

  try {
    if (m === 'GET' && p === '/api/health') {
      return send(res, 200, { ok: true, service: 'andrade-cardoso-api', ts: now() });
    }

    if (m === 'GET' && p === '/api/public/firm') {
      const db = getDb();
      return send(res, 200, {
        firm: db.settings.firm,
        social: db.settings.social,
        plans: db.retainers,
        posts: db.posts,
        team: db.users.map((u) => ({ name: u.name, oab: u.oab, role: u.role, avatar: u.avatar }))
      });
    }

    if (m === 'GET' && p === '/api/public/jurisprudence') {
      const q = url.searchParams.get('q') || '';
      const court = url.searchParams.get('court') || '';
      return send(res, 200, { ...searchJurisprudence({ q, court }), news: getNews() });
    }

    if (m === 'POST' && p === '/api/public/contact') {
      const body = await parseBody(req);
      if (!body.name || !body.email || !body.message) {
        return send(res, 400, { error: 'Informe nome, e-mail e mensagem.' });
      }
      const db = getDb();
      const lead = {
        id: uid('ld'),
        name: body.name,
        company: body.company || '',
        email: body.email,
        phone: body.phone || '',
        source: body.source || 'site',
        stage: 'novo',
        interest: body.interest || body.subject || 'Consulta inicial',
        value: Number(body.value) || 0,
        notes: body.message,
        createdAt: now(),
        updatedAt: now()
      };
      db.leads.unshift(lead);
      const msg = {
        id: uid('msg'),
        channel: body.channel || 'site',
        from: body.name,
        contact: body.email,
        subject: body.subject || lead.interest,
        body: body.message,
        status: 'aberto',
        autoReplied: true,
        createdAt: now()
      };
      db.messages.unshift(msg);
      const aut = db.automations.find((a) => a.id === 'aut_welcome_email' && a.active);
      let auto = null;
      if (aut) {
        auto = runAutomation({
          automation: aut,
          target: body.email,
          vars: { nome: body.name, interesse: lead.interest }
        });
      }
      if ((body.channel === 'whatsapp' || body.phone) && db.automations.find((a) => a.id === 'aut_whatsapp_triagem' && a.active)) {
        const wa = db.automations.find((a) => a.id === 'aut_whatsapp_triagem');
        runAutomation({
          automation: wa,
          target: body.phone || body.email,
          vars: { nome: body.name.split(' ')[0] }
        });
      }
      logActivity(`Novo lead ${lead.name} via ${lead.source}`);
      saveDb();
      return send(res, 201, {
        ok: true,
        leadId: lead.id,
        autoReply: auto?.preview || 'Recebemos sua mensagem. Retornaremos em até 4 horas úteis.'
      });
    }

    if (m === 'POST' && p === '/api/auth/login') {
      const body = await parseBody(req);
      const db = getDb();
      const user = db.users.find((u) => u.email === body.email && u.password === hash(body.password || ''));
      if (!user) return send(res, 401, { error: 'Credenciais inválidas' });
      const t = token();
      const safe = { id: user.id, name: user.name, email: user.email, role: user.role, oab: user.oab, avatar: user.avatar };
      sessions.set(t, safe);
      return send(res, 200, { token: t, user: safe });
    }

    if (m === 'GET' && p === '/api/auth/me') {
      const user = requireAuth(req, res);
      if (!user) return;
      return send(res, 200, { user });
    }

    if (m === 'GET' && p === '/api/dashboard') {
      const user = requireAuth(req, res);
      if (!user) return;
      const db = getDb();
      const mrr = db.clients.filter((c) => c.status === 'ativo').reduce((s, c) => s + c.monthlyFee, 0);
      const pipeline = db.leads.filter((l) => !['ganho', 'perdido'].includes(l.stage)).reduce((s, l) => s + (l.value || 0), 0);
      const paid = db.invoices.filter((i) => i.status === 'pago').reduce((s, i) => s + i.amount, 0);
      const pending = db.invoices.filter((i) => i.status === 'pendente').reduce((s, i) => s + i.amount, 0);
      const stages = ['novo', 'qualificado', 'proposta', 'negociacao', 'ganho', 'perdido'];
      const funnel = stages.map((stage) => ({
        stage,
        count: db.leads.filter((l) => l.stage === stage).length,
        value: db.leads.filter((l) => l.stage === stage).reduce((s, l) => s + (l.value || 0), 0)
      }));
      return send(res, 200, {
        kpis: {
          mrr,
          arr: mrr * 12,
          clients: db.clients.filter((c) => c.status === 'ativo').length,
          cases: db.cases.length,
          pipeline,
          paidMonth: paid,
          pending,
          openMessages: db.messages.filter((x) => x.status === 'aberto').length,
          automationsSent: db.automationLogs.length
        },
        funnel,
        cases: db.cases,
        appointments: db.appointments,
        activities: db.activities.slice(0, 12),
        invoices: db.invoices
      });
    }

    if (p === '/api/leads' && m === 'GET') {
      if (!requireAuth(req, res)) return;
      return send(res, 200, { items: getDb().leads });
    }

    if (p === '/api/leads' && m === 'POST') {
      if (!requireAuth(req, res)) return;
      const body = await parseBody(req);
      const db = getDb();
      const lead = {
        id: uid('ld'),
        name: body.name,
        company: body.company || '',
        email: body.email,
        phone: body.phone || '',
        source: body.source || 'manual',
        stage: body.stage || 'novo',
        interest: body.interest || '',
        value: Number(body.value) || 0,
        notes: body.notes || '',
        createdAt: now(),
        updatedAt: now()
      };
      db.leads.unshift(lead);
      saveDb();
      logActivity(`Lead criado: ${lead.name}`);
      return send(res, 201, { item: lead });
    }

    const leadMatch = p.match(/^\/api\/leads\/([^/]+)$/);
    if (leadMatch && m === 'PATCH') {
      if (!requireAuth(req, res)) return;
      const body = await parseBody(req);
      const db = getDb();
      const lead = db.leads.find((l) => l.id === leadMatch[1]);
      if (!lead) return send(res, 404, { error: 'Lead não encontrado' });
      Object.assign(lead, body, { updatedAt: now() });
      saveDb();
      logActivity(`Lead ${lead.name} atualizado (${lead.stage})`);
      return send(res, 200, { item: lead });
    }

    if (p === '/api/clients' && m === 'GET') {
      if (!requireAuth(req, res)) return;
      return send(res, 200, { items: getDb().clients, plans: getDb().retainers });
    }

    if (p === '/api/clients' && m === 'POST') {
      if (!requireAuth(req, res)) return;
      const body = await parseBody(req);
      const db = getDb();
      const client = {
        id: uid('cli'),
        name: body.name,
        type: body.type || 'pj',
        document: body.document || '',
        email: body.email,
        phone: body.phone || '',
        segment: body.segment || '',
        plan: body.plan || 'essencial',
        monthlyFee: Number(body.monthlyFee) || 0,
        status: 'ativo',
        since: now().slice(0, 10),
        owner: body.owner || 'Ricardo Andrade',
        createdAt: now()
      };
      db.clients.unshift(client);
      saveDb();
      logActivity(`Cliente ${client.name} cadastrado no plano ${client.plan}`);
      return send(res, 201, { item: client });
    }

    if (p === '/api/cases' && m === 'GET') {
      if (!requireAuth(req, res)) return;
      return send(res, 200, { items: getDb().cases });
    }

    if (p === '/api/cases' && m === 'POST') {
      if (!requireAuth(req, res)) return;
      const body = await parseBody(req);
      const db = getDb();
      const item = {
        id: uid('cs'),
        number: body.number,
        title: body.title,
        clientId: body.clientId || '',
        clientName: body.clientName || '',
        court: body.court || '',
        area: body.area || '',
        status: body.status || 'em_andamento',
        phase: body.phase || 'inicial',
        value: Number(body.value) || 0,
        responsible: body.responsible || '',
        deadline: body.deadline || '',
        lastMove: body.lastMove || 'Autos distribuídos.',
        createdAt: now()
      };
      db.cases.unshift(item);
      saveDb();
      return send(res, 201, { item });
    }

    const caseMatch = p.match(/^\/api\/cases\/([^/]+)$/);
    if (caseMatch && m === 'PATCH') {
      if (!requireAuth(req, res)) return;
      const body = await parseBody(req);
      const db = getDb();
      const item = db.cases.find((c) => c.id === caseMatch[1]);
      if (!item) return send(res, 404, { error: 'Processo não encontrado' });
      Object.assign(item, body);
      saveDb();
      return send(res, 200, { item });
    }

    if (p === '/api/appointments' && m === 'GET') {
      if (!requireAuth(req, res)) return;
      return send(res, 200, { items: getDb().appointments });
    }

    if (p === '/api/appointments' && m === 'POST') {
      if (!requireAuth(req, res)) return;
      const body = await parseBody(req);
      const db = getDb();
      const item = {
        id: uid('ap'),
        title: body.title,
        with: body.with,
        type: body.type || 'cliente',
        date: body.date,
        duration: Number(body.duration) || 60,
        location: body.location || 'Escritório',
        status: 'agendado'
      };
      db.appointments.unshift(item);
      saveDb();
      return send(res, 201, { item });
    }

    if (p === '/api/invoices' && m === 'GET') {
      if (!requireAuth(req, res)) return;
      return send(res, 200, { items: getDb().invoices });
    }

    if (p === '/api/invoices' && m === 'POST') {
      if (!requireAuth(req, res)) return;
      const body = await parseBody(req);
      const db = getDb();
      const item = {
        id: uid('inv'),
        clientId: body.clientId || '',
        clientName: body.clientName,
        description: body.description,
        amount: Number(body.amount) || 0,
        status: 'pendente',
        dueDate: body.dueDate,
        paidAt: null,
        type: body.type || 'retainer'
      };
      db.invoices.unshift(item);
      saveDb();
      return send(res, 201, { item });
    }

    const invMatch = p.match(/^\/api\/invoices\/([^/]+)\/pay$/);
    if (invMatch && m === 'POST') {
      if (!requireAuth(req, res)) return;
      const db = getDb();
      const item = db.invoices.find((i) => i.id === invMatch[1]);
      if (!item) return send(res, 404, { error: 'Fatura não encontrada' });
      item.status = 'pago';
      item.paidAt = now().slice(0, 10);
      saveDb();
      logActivity(`Fatura ${item.description} baixada (${item.clientName})`);
      return send(res, 200, { item });
    }

    if (p === '/api/messages' && m === 'GET') {
      if (!requireAuth(req, res)) return;
      return send(res, 200, { items: getDb().messages });
    }

    const msgMatch = p.match(/^\/api\/messages\/([^/]+)$/);
    if (msgMatch && m === 'PATCH') {
      if (!requireAuth(req, res)) return;
      const body = await parseBody(req);
      const db = getDb();
      const item = db.messages.find((x) => x.id === msgMatch[1]);
      if (!item) return send(res, 404, { error: 'Mensagem não encontrada' });
      Object.assign(item, body);
      saveDb();
      return send(res, 200, { item });
    }

    if (p === '/api/automations' && m === 'GET') {
      if (!requireAuth(req, res)) return;
      const db = getDb();
      return send(res, 200, { items: db.automations, logs: db.automationLogs.slice(0, 40) });
    }

    const autMatch = p.match(/^\/api\/automations\/([^/]+)$/);
    if (autMatch && m === 'PATCH') {
      if (!requireAuth(req, res)) return;
      const body = await parseBody(req);
      const db = getDb();
      const item = db.automations.find((a) => a.id === autMatch[1]);
      if (!item) return send(res, 404, { error: 'Automação não encontrada' });
      Object.assign(item, body);
      saveDb();
      return send(res, 200, { item });
    }

    if (p === '/api/automations/run' && m === 'POST') {
      if (!requireAuth(req, res)) return;
      const body = await parseBody(req);
      const db = getDb();
      const automation = db.automations.find((a) => a.id === body.automationId);
      if (!automation) return send(res, 404, { error: 'Automação não encontrada' });
      const log = runAutomation({
        automation,
        target: body.target || 'teste@andradecardoso.adv.br',
        vars: body.vars || { nome: 'Cliente', processo: '0000000-00.0000.0.00.0000', responsavel: 'Banca', cliente: 'Cliente', fatura: 'INV', plano: 'Empresarial' }
      });
      return send(res, 200, { log });
    }

    if (p === '/api/jurisprudence' && m === 'GET') {
      if (!requireAuth(req, res)) return;
      const q = url.searchParams.get('q') || '';
      const court = url.searchParams.get('court') || '';
      const db = getDb();
      return send(res, 200, {
        ...searchJurisprudence({ q, court }),
        news: getNews(),
        watchlists: db.watchlists,
        courts: getCourts()
      });
    }

    if (p === '/api/watchlists' && m === 'POST') {
      if (!requireAuth(req, res)) return;
      const body = await parseBody(req);
      const db = getDb();
      const item = {
        id: uid('wl'),
        keyword: body.keyword,
        courts: body.courts || ['STF', 'STJ'],
        active: true,
        hits: 0,
        lastHit: now()
      };
      db.watchlists.unshift(item);
      saveDb();
      return send(res, 201, { item });
    }

    if (p === '/api/settings' && m === 'GET') {
      if (!requireAuth(req, res)) return;
      return send(res, 200, getDb().settings);
    }

    if (p === '/api/settings' && m === 'PUT') {
      if (!requireAuth(req, res)) return;
      const body = await parseBody(req);
      const db = getDb();
      db.settings = { ...db.settings, ...body };
      saveDb();
      return send(res, 200, db.settings);
    }

    send(res, 404, { error: 'Rota não encontrada' });
  } catch (err) {
    send(res, 500, { error: 'Erro interno', detail: String(err.message || err) });
  }
}

const server = http.createServer((req, res) => {
  handle(req, res);
});

server.listen(PORT, '0.0.0.0', () => {
  console.log(`Andrade Cardoso API on :${PORT}`);
});
